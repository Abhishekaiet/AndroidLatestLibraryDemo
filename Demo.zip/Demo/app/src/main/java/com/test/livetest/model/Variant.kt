package com.test.livetest.model

data class Variant(
    val name: String,
    val total: Int,
)
