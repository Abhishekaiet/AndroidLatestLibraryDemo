package com.test.livetest.ui.login

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.commentsold.livetest.databinding.FragmentLoginBinding
import com.test.livetest.ui.base.BaseFragment
import com.test.livetest.utils.extensions.hiltLiveTestNavGraphViewModels
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class LoginFragment : BaseFragment<FragmentLoginBinding, LoginState, LoginViewModel>() {

    override val viewModel: LoginViewModel by hiltLiveTestNavGraphViewModels()

    override fun initView() {
        with(binding) {
            guestButton.setOnClickListener {
                viewModel.handleGuestButtonTap()
            }

            userButton.setOnClickListener {
                viewModel.handleUserButtonTap()
            }
        }
    }

    override fun render(state: LoginState) {
        if(state.isLoggedIn) {
            findNavController().navigate(
                LoginFragmentDirections.loginToHome()
            )
        }
    }

    override fun getViewBinding(
        inflater: LayoutInflater,
        container: ViewGroup?
    ): FragmentLoginBinding = FragmentLoginBinding.inflate(inflater, container, false)
}