package com.test.livetest.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import com.commentsold.livetest.databinding.FragmentHomeBinding
import com.test.livetest.ui.base.BaseFragment
import com.test.livetest.ui.base.autoCleaned
import com.test.livetest.utils.extensions.hiltLiveTestNavGraphViewModels
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class HomeFragment : BaseFragment<FragmentHomeBinding, HomeState, HomeViewModel>() {

    override val viewModel: HomeViewModel by hiltLiveTestNavGraphViewModels()

    private val liveProductAdapter by autoCleaned(
        initializer = { HomeAdapter() }
    )

    override fun initView() {
        with(binding) {
            liveProductRecyclerview.adapter = liveProductAdapter
        }
        viewModel.getProductList()
    }


    override fun render(state: HomeState) {
        val foundList = state.productList
        liveProductAdapter.submitList(foundList)
    }

    override fun getViewBinding(
        inflater: LayoutInflater,
        container: ViewGroup?
    ): FragmentHomeBinding = FragmentHomeBinding.inflate(inflater, container, false)
}