package com.test.livetest.model

data class Inventory(
    val color: String,
    val inventory_id: Int,
    val position: Int,
    val price: Double,
    val quantity: Int,
    val size: String
)