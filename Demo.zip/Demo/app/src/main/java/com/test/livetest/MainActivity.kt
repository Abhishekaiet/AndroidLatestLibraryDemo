package com.test.livetest

import android.os.Bundle
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.commentsold.livetest.R
import com.commentsold.livetest.databinding.ActivityMainBinding
import com.test.livetest.utils.extensions.hide
import com.test.livetest.utils.extensions.show
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val navView: BottomNavigationView = binding.navView

        val navHostFragment: NavHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment_activity_main) as NavHostFragment? ?: return

        navView.setupWithNavController(navHostFragment.navController)
        setUpBottomNav(binding, navHostFragment.navController)
    }

    private fun setUpBottomNav(binding: ActivityMainBinding, navController: NavController) {
        with(binding) {
            navController.addOnDestinationChangedListener { _, destination, _ ->
                when (destination.id) {
                    R.id.navigation_login -> navView.hide()
                    R.id.navigation_home -> navView.show()
                    R.id.navigation_favorites -> navView.show()
                    R.id.navigation_account ->navView.show()
                    else ->navView.hide()
                }
            }
        }
    }
}