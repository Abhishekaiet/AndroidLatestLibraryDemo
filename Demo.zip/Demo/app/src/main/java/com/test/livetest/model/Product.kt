package com.test.livetest.model

class Product : ArrayList<ProductItem>()