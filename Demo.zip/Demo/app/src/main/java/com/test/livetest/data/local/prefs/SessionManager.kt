package com.test.livetest.data.local.prefs

import javax.inject.Singleton

@Singleton
interface SessionManager {
    fun saveToken(token: String?)
    fun getToken(): String?
}
