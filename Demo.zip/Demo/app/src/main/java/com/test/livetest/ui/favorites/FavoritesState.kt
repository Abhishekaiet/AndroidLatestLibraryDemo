package com.test.livetest.ui.favorites

import com.test.livetest.model.ProductItem
import com.test.livetest.model.Variant
import com.test.livetest.ui.base.State

data class FavoritesState(
    val favorites: List<ProductItem>? = null,
    val selectedFavorite: ProductItem? = null,
    val colorVariantList: List<Variant> = listOf(),
    val sizeVariantList: List<Variant> = listOf()
) : State
