package com.test.livetest.ui.base

interface State
