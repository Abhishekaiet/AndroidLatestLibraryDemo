package com.test.livetest.ui.home

import com.test.livetest.model.ProductItem
import com.test.livetest.ui.base.State

data class HomeState(
    val productList: List<ProductItem>? = null
) : State