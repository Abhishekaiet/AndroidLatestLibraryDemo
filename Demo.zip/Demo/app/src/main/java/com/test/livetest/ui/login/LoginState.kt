package com.test.livetest.ui.login

import com.test.livetest.ui.base.State

data class LoginState(
    val isLoggedIn: Boolean = false
) : State